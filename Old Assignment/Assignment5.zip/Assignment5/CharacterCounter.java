public class CharacterCounter {
    public static void main(String[] args) {
        // WRITE YOUR CODE HERE
    }
}
